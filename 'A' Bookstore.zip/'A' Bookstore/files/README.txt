All the images are collected from https://search.creativecommons.org/ and https://image.baidu.com/

For the codes about images slider from html, css and js file, I learnt and used the method from W3School:https://www.w3schools.com/howto/howto_js_slideshow.asp

